#include <stdio.h>
#include "12_2_calculator.h"

int main(){
    printf("%d", printAdd(10, 20));
    return 0;
}
